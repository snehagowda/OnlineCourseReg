<html>
<head>
<title>Welcome Page</title>
<link href="style.css" rel="stylesheet" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
    
<body>
    <header>
        <div class="row">
            <div class="logo">
            <img src="bms.png">
            </div>
           <ul class="main-nav">
            <li ><a href="http://localhost/HomePage/HomePage.php">HOME</a></li>
            <li><a href="http://localhost/Catalog/aboutUs.php">ABOUT US</a></li>
            <li><a href="http://localhost/Catalog/contactUs.php">CONTACT US</a></li>
            <li><a href="http://localhost/request/request.php">REQUEST</a></li>
           
        </ul>
        </div>
        
        <div class="hero">
        <h1>Welcome Students </h1>
            <div class="button">
                <a href="http://localhost/Student/Login/studentlog.php" id="stud" class=" btn btn-one"><b>Student</b></a>
                
                    <a href="http://localhost/Admin/logs/adminLog.php" class="btn btn-two"><b>Admin</b></a>
                    <a href="http://localhost/Proctor/proc_log.php" class="btn btn-three"><b>Proctor</b></a>
                    <a href="http://localhost/HOD/HodLog.php" class="btn btn-four"><b>HOD</b></a>
                
            </div>
            
        </div>
        
     
     
    </header>
    
</body>
</html>