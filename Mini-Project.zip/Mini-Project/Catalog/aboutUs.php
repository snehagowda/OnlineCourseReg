<html>
<head>
    <title>About Us Page</title>
<link href="style1.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#E6E6FA">

<div class="container">
  <div style="text-align:center">
    <h2>About Us</h2>
    <p>A message for our viewers...</p>
  </div>
  <div class="row">
    <div class="column">
      <img src="abts.jpg" style="width:100%">
    </div>
    <div class="column">
      <form action="/action_page.php">
        <label for="fname" style="height:170p">We have developer this Web Application to automate the course registration process.</label>
      </form>
    </div>
  </div>
</div>
</body>
</html>